#!/bin/sh
ctags -R --exclude=iso --exclude=leg --exclude=setups --exclude=scripts --exclude="legion_port*" --exclude="*.pl" --exclude=TODO --exclude="*.bin" --exclude="*.iso" --exclude="*.sh"
