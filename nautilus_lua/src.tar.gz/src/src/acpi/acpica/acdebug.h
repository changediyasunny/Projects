/* Not used. Replace when additional ACPICA functionality required. */
